﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8Q6AF3G\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}
