﻿namespace Cinema.DataProcessor
{
    using System;
    using System.Linq;
    using Data;
    using Newtonsoft.Json;

    public class Serializer
    {
        public static string ExportTopMovies(CinemaContext context, int rating)
        {
            var movies = context.Movies
                .Where(x => x.Rating >= rating && x.Projections.Count > 0 && x.Projections.Any(p => p.Tickets.Count > 0))
                .OrderByDescending(r => r.Rating)
                .ThenByDescending(t => t.Projections.Sum(p => p.Tickets.Sum(pr => pr.Price)))
                .Select(x => new
                {
                    MovieName = x.Title,
                    Rating = x.Rating.ToString("0.00"),
                    TotalIncomes = x.Projections.Sum(p => p.Tickets.Sum(t => t.Price)).ToString("0.00"),
                    Customers = x.Projections.SelectMany(p => p.Tickets.Select(t => t.Customer))
                    .Select(c => new
                    {
                        FirstName = c.FirstName,
                        LastName = c.LastName,
                        Balance = c.Balance.ToString("0.00")
                    })
                    .OrderByDescending(b => b.Balance)
                    .ThenBy(f => f.FirstName)
                    .ThenBy(l => l.LastName)
                    .ToArray()
                })
                .Take(10)
                .ToArray();

            var jsonResult = JsonConvert.SerializeObject(movies, Formatting.Indented);

            return jsonResult;
        }

        public static string ExportTopCustomers(CinemaContext context, int age)
        {
            throw new NotImplementedException();
        }
    }
}