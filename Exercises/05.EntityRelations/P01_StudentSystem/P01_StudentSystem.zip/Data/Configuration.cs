﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-8Q6AF3G\\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
