﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models
{
    public enum PredictionType
    {
        HomeTeam,
        Draw,
        AwayTeam
    }
}
