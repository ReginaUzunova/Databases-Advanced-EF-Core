﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-8Q6AF3G\\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}
