﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();

            //09
            //var suppliersJson = File.ReadAllText(@"D:\DatabasesAdvanced-EF-February2019\10.JavaScriptObjectNotation-JSON\Car Dealer - Skeleton\CarDealer\Datasets\suppliers.json");
            //var result = ImportSuppliers(context, suppliersJson);

            //10
            //var partsJson = File.ReadAllText(@"D:\DatabasesAdvanced-EF-February2019\10.JavaScriptObjectNotation-JSON\Car Dealer - Skeleton\CarDealer\Datasets\parts.json");
            //var result = ImportParts(context, partsJson);

            var carsJson = File.ReadAllText(@"D:\DatabasesAdvanced-EF-February2019\10.JavaScriptObjectNotation-JSON\Car Dealer - Skeleton\CarDealer\Datasets\cars.json");
            var result = ImportCars(context, carsJson);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            Supplier[] suppliers = JsonConvert.DeserializeObject<Supplier[]>(inputJson);

            context.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            Part[] parts = JsonConvert.DeserializeObject<Part[]>(inputJson);
            List<Part> correctParts = new List<Part>();

            foreach (var item in parts)
            {
                if (context.Suppliers.Any(s => s.Id == item.SupplierId))
                {
                    correctParts.Add(item);
                }
            }

            context.AddRange(correctParts);
            context.SaveChanges();

            return $"Successfully imported {correctParts.Count()}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            Car[] cars = JsonConvert.DeserializeObject<Car[]>(inputJson);

            context.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count()}.";
        }
    }
}